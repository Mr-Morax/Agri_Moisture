import { useState, useRef, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import {
  Leaf,
  Phone,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  CheckCircle2,
  Home,
  Map,
  Bot,
  Droplets,
  CloudRain,
  BarChart2,
  Settings,
  Thermometer,
  Wind,
  AlertTriangle,
  TrendingUp,
  Zap,
  ChevronRight,
  RefreshCw,
  Bell,
  User,
  CloudSun,
  Gauge,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type AuthTab = "otp" | "password";
type OtpStep = "phone" | "verify";
type NavTab = "dashboard" | "map" | "ai" | "irrigation" | "weather" | "analytics" | "settings";

// ─── Mock data ────────────────────────────────────────────────────────────────

const moistureHistory = [
  { time: "6am", value: 62 },
  { time: "8am", value: 59 },
  { time: "10am", value: 55 },
  { time: "12pm", value: 48 },
  { time: "2pm", value: 43 },
  { time: "4pm", value: 38 },
  { time: "6pm", value: 35 },
];

const weeklyRainfall = [
  { day: "Mon", mm: 0 },
  { day: "Tue", mm: 4.2 },
  { day: "Wed", mm: 0 },
  { day: "Thu", mm: 1.8 },
  { day: "Fri", mm: 0 },
  { day: "Sat", mm: 6.5 },
  { day: "Sun", mm: 0 },
];

// ─── Login Page ───────────────────────────────────────────────────────────────

function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [tab, setTab] = useState<AuthTab>("otp");
  const [otpStep, setOtpStep] = useState<OtpStep>("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleOtpChange = (i: number, val: string) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[i] = val;
    setOtp(next);
    if (val && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const handleOtpKeyDown = (i: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) otpRefs.current[i - 1]?.focus();
  };

  const simulate = (cb: () => void) => {
    setLoading(true);
    setTimeout(() => { setLoading(false); cb(); }, 1200);
  };

  // Crop thumbnail URLs for the bottom strip and corner cards
  const cropThumbs = [
    "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=120&h=120&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=120&h=120&fit=crop&auto=format",
  ];

  return (
    <div
      className="min-h-screen flex flex-col overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #071a09 0%, #0f2412 40%, #183318 70%, #1f4022 100%)",
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      <style>{`
        .font-display { font-family: 'Outfit', sans-serif; }
        .font-mono-data { font-family: 'JetBrains Mono', monospace; }
      `}</style>

      {/* ── Top satellite image cards ── */}
      <div className="relative w-full flex justify-between items-start px-4 pt-10 pb-2 pointer-events-none">
        {/* Left card — Sentinel 1 */}
        <div className="relative rounded-xl overflow-hidden shadow-2xl border border-white/20 w-32 h-24"
          style={{ transform: "rotate(-5deg) translateY(6px)" }}>
          <img
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=220&h=160&fit=crop&auto=format"
            alt="Sentinel 1 SAR crop view"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 55%)" }} />
          <div className="absolute bottom-0 left-0 right-0 px-2 py-1.5">
            <p className="text-white/90 font-mono-data font-semibold leading-none" style={{ fontSize: 9 }}>Sentinel 1</p>
            <p className="text-white/50 font-mono-data leading-none mt-0.5" style={{ fontSize: 7 }}>SAR · C-Band</p>
          </div>
        </div>

        {/* Right card — Sentinel 2 */}
        <div className="relative rounded-xl overflow-hidden shadow-2xl border border-white/20 w-32 h-24"
          style={{ transform: "rotate(5deg) translateY(6px)" }}>
          <img
            src="https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=220&h=160&fit=crop&auto=format"
            alt="Sentinel 2 NDVI multispectral crop view"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 55%)" }} />
          <div className="absolute bottom-0 left-0 right-0 px-2 py-1.5">
            <p className="text-white/90 font-mono-data font-semibold leading-none" style={{ fontSize: 9 }}>Sentinel 2</p>
            <p className="text-white/50 font-mono-data leading-none mt-0.5" style={{ fontSize: 7 }}>NDVI · Multispectral</p>
          </div>
        </div>
      </div>

      {/* ── Brand ── */}
      <div className="text-center px-6 pt-2 pb-5">
        <h1 className="font-display font-extrabold text-white leading-tight mb-1"
          style={{ fontSize: "clamp(1.7rem, 6vw, 2.2rem)", letterSpacing: "-0.01em" }}>
          AgriXplorer
        </h1>
        <p className="text-white/40 text-xs tracking-wide">
          AI-powered crop intelligence platform
        </p>
      </div>

      {/* ── Form card ── */}
      <div className="mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden"
        style={{ maxWidth: 420, marginLeft: "auto", marginRight: "auto", width: "calc(100% - 2rem)" }}>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          {(["otp", "password"] as AuthTab[]).map((t) => (
            <button
              key={t}
              onClick={() => { setTab(t); setOtpStep("phone"); }}
              className="flex-1 py-3.5 text-xs font-semibold tracking-wide transition-all relative"
              style={{
                color: tab === t ? "#1a4020" : "#9ca3af",
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {t === "otp" ? "OTP Login" : "Password Login"}
              {tab === t && (
                <span className="absolute bottom-0 left-4 right-4 h-0.5 rounded-full"
                  style={{ background: "#4a9b3a" }} />
              )}
            </button>
          ))}
        </div>

        <div className="px-6 py-5">
          {/* Phone field */}
          <div className="mb-4">
            <label className="block font-mono-data text-gray-400 mb-1.5" style={{ fontSize: 10, letterSpacing: "0.08em" }}>
              MOBILE NUMBER
            </label>
            <div className="flex items-center gap-2 rounded-lg px-3 py-2.5 border border-gray-200 focus-within:border-[#4a9b3a] transition-colors bg-gray-50">
              <Phone size={14} className="text-gray-400 shrink-0" />
              <span className="font-mono-data text-xs text-gray-400">+91</span>
              <div className="w-px h-3.5 bg-gray-200" />
              <input
                type="tel"
                maxLength={10}
                placeholder="98765 43210"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                className="flex-1 bg-transparent outline-none font-mono-data text-sm text-gray-800 placeholder:text-gray-300"
              />
            </div>
          </div>

          {/* OTP flow */}
          {tab === "otp" && (
            <>
              {otpStep === "phone" ? (
                <button
                  onClick={() => { if (phone.length >= 10) simulate(() => setOtpStep("verify")); }}
                  disabled={phone.length < 10 || loading}
                  className="w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-40 mt-1"
                  style={{ background: "#1a4020", color: "#fff" }}
                >
                  {loading
                    ? <span className="font-mono-data text-xs animate-pulse">Sending OTP…</span>
                    : <><span>Send OTP</span><ArrowRight size={14} /></>}
                </button>
              ) : (
                <>
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <label className="font-mono-data text-gray-400" style={{ fontSize: 10, letterSpacing: "0.08em" }}>
                        ENTER 6-DIGIT OTP
                      </label>
                      <button onClick={() => setOtpStep("phone")}
                        className="text-xs text-[#4a9b3a] hover:underline">
                        Change
                      </button>
                    </div>
                    <p className="text-xs text-gray-400 mb-3">
                      Sent to +91 {phone.slice(0, 5)} {phone.slice(5)}
                    </p>
                    <div className="flex gap-1.5">
                      {otp.map((d, i) => (
                        <input
                          key={i}
                          ref={(el) => { otpRefs.current[i] = el; }}
                          type="text"
                          inputMode="numeric"
                          maxLength={1}
                          value={d}
                          onChange={(e) => handleOtpChange(i, e.target.value)}
                          onKeyDown={(e) => handleOtpKeyDown(i, e)}
                          className="flex-1 h-10 text-center font-mono-data text-base font-bold rounded-lg border border-gray-200 outline-none focus:border-[#4a9b3a] transition-all text-gray-800 bg-gray-50"
                        />
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={() => { if (otp.join("").length === 6) simulate(onLogin); }}
                    disabled={otp.join("").length < 6 || loading}
                    className="w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                    style={{ background: "#1a4020", color: "#fff" }}
                  >
                    {loading
                      ? <span className="font-mono-data text-xs animate-pulse">Verifying…</span>
                      : <><CheckCircle2 size={14} /><span>Verify & Login</span></>}
                  </button>
                  <p className="text-center text-xs text-gray-400 mt-2.5">
                    Didn't receive?{" "}
                    <button className="text-[#4a9b3a] hover:underline">Resend in 30s</button>
                  </p>
                </>
              )}
            </>
          )}

          {/* Password flow */}
          {tab === "password" && (
            <>
              <div className="mb-1">
                <label className="block font-mono-data text-gray-400 mb-1.5" style={{ fontSize: 10, letterSpacing: "0.08em" }}>
                  PASSWORD
                </label>
                <div className="flex items-center gap-2 rounded-lg px-3 py-2.5 border border-gray-200 focus-within:border-[#4a9b3a] transition-colors bg-gray-50">
                  <Lock size={14} className="text-gray-400 shrink-0" />
                  <input
                    type={showPass ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder:text-gray-300"
                  />
                  <button onClick={() => setShowPass(!showPass)} className="text-gray-300 hover:text-gray-500 transition-colors">
                    {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                <div className="flex justify-end mt-1.5">
                  <button className="text-xs text-[#4a9b3a] hover:underline">Forgot password?</button>
                </div>
              </div>
              <button
                onClick={() => { if (phone.length >= 10 && password.length >= 4) simulate(onLogin); }}
                disabled={phone.length < 10 || password.length < 4 || loading}
                className="w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-40 mt-3"
                style={{ background: "#1a4020", color: "#fff" }}
              >
                {loading
                  ? <span className="font-mono-data text-xs animate-pulse">Signing in…</span>
                  : <><span>Sign In</span><ArrowRight size={14} /></>}
              </button>
            </>
          )}
        </div>
      </div>

      {/* ── Bottom crop library strip ── */}
      <div className="mt-auto pt-6 pb-4 px-4">
        <p className="text-center font-mono-data text-white/30 mb-3"
          style={{ fontSize: 9, letterSpacing: "0.15em" }}>
          EXPLORE OUR VAST CROP DATA LIBRARY
        </p>
        <div className="flex gap-2 overflow-x-auto pb-1"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
          {cropThumbs.map((src, i) => (
            <div key={i}
              className="shrink-0 rounded-lg overflow-hidden border border-white/10 shadow-md"
              style={{ width: 72, height: 52 }}>
              <img
                src={src}
                alt={`Crop sample ${i + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

const navItems: { key: NavTab; icon: React.ReactNode; label: string }[] = [
  { key: "dashboard", icon: <Home size={20} />, label: "Dashboard" },
  { key: "map", icon: <Map size={20} />, label: "Map" },
  { key: "ai", icon: <Bot size={20} />, label: "AI" },
  { key: "irrigation", icon: <Droplets size={20} />, label: "Irrigation" },
  { key: "weather", icon: <CloudSun size={20} />, label: "Weather" },
  { key: "analytics", icon: <BarChart2 size={20} />, label: "Analytics" },
  { key: "settings", icon: <Settings size={20} />, label: "Settings" },
];

function StatusCard({
  icon,
  label,
  value,
  unit,
  sub,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit?: string;
  sub?: string;
  accent?: string;
}) {
  return (
    <div
      className="rounded-2xl p-4 flex flex-col gap-1"
      style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-mono-data text-gray-400 uppercase tracking-wider">{label}</span>
        <span style={{ color: accent || "#4a9b3a" }}>{icon}</span>
      </div>
      <div className="flex items-end gap-1">
        <span className="font-display font-bold text-2xl text-gray-800">{value}</span>
        {unit && <span className="font-mono-data text-xs text-gray-400 mb-0.5">{unit}</span>}
      </div>
      {sub && <span className="text-xs text-gray-400">{sub}</span>}
    </div>
  );
}

function MapTab() {
  return (
    <div className="p-5 space-y-4 pb-20">
      <h2 className="font-display font-bold text-xl text-gray-800">Field Map</h2>
      <div
        className="rounded-2xl overflow-hidden relative"
        style={{ height: 320, background: "#ddebd8", border: "1px solid rgba(26,64,32,0.15)" }}
      >
        {/* Satellite Background */}
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1722082840106-c6508ee966ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBtYXAlMjBncmVlbiUyMHRleHR1cmV8ZW58MXx8fHwxNzgyNDA4OTM2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Satellite map green texture"
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />
        {/* Satellite-style grid */}
        <svg width="100%" height="100%" className="absolute inset-0 opacity-20">
          {Array.from({ length: 8 }).map((_, i) => (
            <line key={`h-${i}`} x1="0" y1={`${(i + 1) * 12.5}%`} x2="100%" y2={`${(i + 1) * 12.5}%`}
              stroke="#1a4020" strokeWidth="1" />
          ))}
          {Array.from({ length: 6 }).map((_, i) => (
            <line key={`v-${i}`} x1={`${(i + 1) * 16.67}%`} y1="0" x2={`${(i + 1) * 16.67}%`} y2="100%"
              stroke="#1a4020" strokeWidth="1" />
          ))}
        </svg>
        {/* Field zones */}
        <div className="absolute inset-4 rounded-xl overflow-hidden">
          <div className="grid grid-cols-3 grid-rows-3 gap-1 h-full">
            {[85, 62, 78, 91, 35, 70, 55, 88, 45].map((m, i) => (
              <div
                key={i}
                className="rounded-lg flex items-center justify-center text-xs font-mono-data font-bold text-white backdrop-blur-sm"
                style={{
                  background: m > 75
                    ? "rgba(74,155,58,0.75)"
                    : m > 50
                    ? "rgba(255,193,7,0.75)"
                    : "rgba(192,57,43,0.75)",
                }}
              >
                {m}%
              </div>
            ))}
          </div>
        </div>
        <div
          className="absolute bottom-3 right-3 text-xs font-mono-data px-3 py-1.5 rounded-lg"
          style={{ background: "rgba(255,255,255,0.9)", color: "#1a4020" }}
        >
          Moisture Heatmap
        </div>
      </div>
      <div className="flex gap-3 text-xs font-mono-data">
        {[["#4a9b3a", "High (>75%)"], ["#FFC107", "Medium (50-75%)"], ["#c0392b", "Low (<50%)"]].map(([c, l]) => (
          <div key={l} className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded" style={{ background: c }} />
            <span className="text-gray-500">{l}</span>
          </div>
        ))}
      </div>

      {/* Sentinel Data Images */}
      <div className="mt-6">
        <h3 className="font-display font-bold text-lg text-gray-800 mb-3">Sentinel-1 & 2 Data</h3>
        <div className="relative h-44 w-full">
          {/* Back Card (NDVI) */}
          <div className="absolute right-0 top-0 w-3/5 h-32 rounded-xl overflow-hidden shadow-md" style={{ border: "2px solid #fff" }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1557343569-b1d5b655b7cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcm9uZSUyMGNyb3AlMjBmaWVsZCUyMHZpZXd8ZW58MXx8fHwxNzgyNDA4OTMzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Sentinel 2 NDVI field view"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-3 pt-6">
              <p className="text-white text-xs font-mono-data font-bold">Sentinel-2 NDVI</p>
              <p className="text-white/80 text-[10px]">Vegetation health</p>
            </div>
          </div>
          {/* Front Card (SAR) */}
          <div className="absolute left-0 bottom-0 w-3/5 h-32 rounded-xl overflow-hidden shadow-lg z-10" style={{ border: "2px solid #fff" }}>
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1519082572439-7ed19908e47e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBpbWFnZXJ5JTIwY3JvcCUyMGZpZWxkfGVufDF8fHx8MTc4MjQwODkzMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Sentinel 1 Satellite crop view"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-3 pt-6">
              <p className="text-white text-xs font-mono-data font-bold">Sentinel-1 SAR</p>
              <p className="text-white/80 text-[10px]">Soil moisture index</p>
            </div>
          </div>
        </div>
      </div>

      <div
        className="rounded-2xl p-4 mt-6"
        style={{ background: "#f4f7f2", border: "1px solid rgba(26,64,32,0.1)" }}
      >
        <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider mb-1">Field Summary</p>
        <div className="grid grid-cols-2 gap-3 mt-3">
          {[["Total Area", "12 Acres"], ["Zones", "9 Sections"], ["Avg Moisture", "67.7%"], ["Alert Zones", "2"]].map(([k, v]) => (
            <div key={k}>
              <p className="text-xs text-gray-400">{k}</p>
              <p className="font-display font-bold text-gray-800">{v}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AITab() {
  return (
    <div className="p-5 space-y-4">
      <h2 className="font-display font-bold text-xl text-gray-800">AI Analysis</h2>
      {/* Crop Detection */}
      <div className="rounded-2xl p-5" style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
        <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider mb-4">Crop Detection</p>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "Crop Type", value: "Soybean", icon: "🌱" },
            { label: "Confidence", value: "95%", icon: "🎯" },
            { label: "Moisture Stress", value: "Moderate", icon: "⚠️" },
            { label: "Water Deficit", value: "18 mm", icon: "💧" },
          ].map(({ label, value, icon }) => (
            <div key={label} className="rounded-xl p-3" style={{ background: "#f4f7f2" }}>
              <p className="text-lg mb-1">{icon}</p>
              <p className="text-xs text-gray-400 font-mono-data">{label}</p>
              <p className="font-display font-bold text-gray-800 text-sm">{value}</p>
            </div>
          ))}
        </div>
      </div>
      {/* AI Recommendation */}
      <div
        className="rounded-2xl p-5"
        style={{
          background: "linear-gradient(135deg, #1a4020 0%, #2d6b35 100%)",
        }}
      >
        <div className="flex items-center gap-2 mb-3">
          <Droplets size={18} className="text-white" />
          <p className="text-white font-semibold text-sm">💧 AI Recommendation</p>
        </div>
        <p className="text-white font-display font-bold text-lg mb-4">
          Irrigate within 24 hours
        </p>
        <div className="space-y-2.5">
          {[
            ["Required Water", "20 mm"],
            ["Priority", "High"],
            ["Best Time", "6:00 AM"],
            ["Method", "Drip Irrigation"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between items-center">
              <span className="text-white/60 text-sm">{k}</span>
              <span
                className="font-mono-data text-xs font-semibold px-2.5 py-1 rounded-lg"
                style={{
                  background: "rgba(255,255,255,0.15)",
                  color: "#fff",
                }}
              >
                {v}
              </span>
            </div>
          ))}
        </div>
      </div>
      {/* Growth stage */}
      <div className="rounded-2xl p-5" style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
        <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider mb-3">Growth Stage</p>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style={{ background: "#ddebd8" }}>
            🌾
          </div>
          <div>
            <p className="font-display font-bold text-gray-800">Reproductive Stage</p>
            <p className="text-xs text-gray-400">Day 62 of 120</p>
          </div>
        </div>
        <div className="w-full h-2 rounded-full" style={{ background: "#e4ede0" }}>
          <div className="h-full rounded-full" style={{ width: "52%", background: "#4a9b3a" }} />
        </div>
        <p className="text-xs text-gray-400 font-mono-data mt-1.5">52% of growing season complete</p>
      </div>
    </div>
  );
}

function IrrigationTab() {
  const [active, setActive] = useState(false);
  return (
    <div className="p-5 space-y-4">
      <h2 className="font-display font-bold text-xl text-gray-800">Irrigation Control</h2>
      {/* Master toggle */}
      <div
        className="rounded-2xl p-5 flex items-center justify-between"
        style={{ background: active ? "linear-gradient(135deg,#1a4020,#2d6b35)" : "#fff", border: "1px solid rgba(26,64,32,0.1)", transition: "background 0.3s" }}
      >
        <div>
          <p className={`font-display font-bold text-lg ${active ? "text-white" : "text-gray-800"}`}>
            {active ? "Irrigation Active" : "Irrigation Off"}
          </p>
          <p className={`text-sm ${active ? "text-white/60" : "text-gray-400"}`}>
            {active ? "Drip system running — Zone A" : "Tap to start irrigation"}
          </p>
        </div>
        <button
          onClick={() => setActive(!active)}
          className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all active:scale-95"
          style={{ background: active ? "rgba(255,255,255,0.2)" : "#ddebd8" }}
        >
          <Droplets size={28} style={{ color: active ? "#fff" : "#1a4020" }} />
        </button>
      </div>
      {/* Zones */}
      <p className="font-semibold text-gray-700 text-sm px-1">Field Zones</p>
      <div className="space-y-3">
        {[
          { zone: "Zone A — North", status: "Running", pct: 78, dur: "45 min" },
          { zone: "Zone B — South", status: "Scheduled", pct: 35, dur: "30 min" },
          { zone: "Zone C — East", status: "Idle", pct: 90, dur: "—" },
          { zone: "Zone D — West", status: "Low", pct: 22, dur: "60 min" },
        ].map(({ zone, status, pct, dur }) => (
          <div key={zone}
            className="rounded-xl p-4 flex items-center justify-between"
            style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}
          >
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-gray-800 text-sm truncate">{zone}</p>
              <div className="w-full h-1.5 rounded-full mt-2" style={{ background: "#e4ede0" }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${pct}%`,
                    background: pct > 60 ? "#4a9b3a" : pct > 40 ? "#FFC107" : "#c0392b",
                  }}
                />
              </div>
              <p className="text-xs text-gray-400 font-mono-data mt-1">{pct}% moisture</p>
            </div>
            <div className="ml-4 text-right shrink-0">
              <span
                className="text-xs font-mono-data font-semibold px-2 py-0.5 rounded-lg"
                style={{
                  background:
                    status === "Running" ? "#ddebd8"
                    : status === "Scheduled" ? "#fff3cd"
                    : status === "Low" ? "#fde8e8"
                    : "#f4f7f2",
                  color:
                    status === "Running" ? "#1a4020"
                    : status === "Scheduled" ? "#856404"
                    : status === "Low" ? "#c0392b"
                    : "#567a52",
                }}
              >
                {status}
              </span>
              <p className="text-xs text-gray-400 mt-1">{dur}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WeatherTab() {
  return (
    <div className="p-5 space-y-4">
      <h2 className="font-display font-bold text-xl text-gray-800">Weather</h2>
      {/* Current */}
      <div
        className="rounded-2xl p-5"
        style={{ background: "linear-gradient(135deg,#1a4020,#2d6b35)" }}
      >
        <p className="text-white/60 text-xs font-mono-data uppercase tracking-wider mb-2">
          Pune, Maharashtra
        </p>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-white font-display font-bold text-5xl">28°C</p>
            <p className="text-white/70 text-sm mt-1">Partly Cloudy</p>
          </div>
          <div className="text-right space-y-1">
            {[["Humidity", "72%"], ["Wind", "14 km/h"], ["UV Index", "6"]].map(([k, v]) => (
              <p key={k} className="text-white/60 text-xs font-mono-data">{k}: <span className="text-white">{v}</span></p>
            ))}
          </div>
        </div>
      </div>
      {/* Forecast */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { day: "Mon", icon: "☀️", hi: 31, lo: 22 },
          { day: "Tue", icon: "🌦", hi: 28, lo: 21 },
          { day: "Wed", icon: "🌧", hi: 25, lo: 19 },
          { day: "Thu", icon: "⛅", hi: 29, lo: 20 },
        ].map(({ day, icon, hi, lo }) => (
          <div key={day}
            className="rounded-xl p-3 text-center"
            style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}
          >
            <p className="text-xs font-mono-data text-gray-400">{day}</p>
            <p className="text-xl my-1">{icon}</p>
            <p className="text-xs font-bold text-gray-800">{hi}°</p>
            <p className="text-xs text-gray-400">{lo}°</p>
          </div>
        ))}
      </div>
      {/* Weekly rainfall chart */}
      <div className="rounded-2xl p-5" style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
        <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider mb-4">Weekly Rainfall (mm)</p>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={weeklyRainfall}>
            <CartesianGrid key="wth-grid" strokeDasharray="3 3" stroke="rgba(26,64,32,0.07)" />
            <XAxis key="wth-x" dataKey="day" tick={{ fontFamily: "JetBrains Mono", fontSize: 10, fill: "#567a52" }} axisLine={false} tickLine={false} />
            <YAxis key="wth-y" tick={{ fontFamily: "JetBrains Mono", fontSize: 10, fill: "#567a52" }} axisLine={false} tickLine={false} width={24} />
            <Tooltip key="wth-tt" contentStyle={{ fontFamily: "JetBrains Mono", fontSize: 11, borderRadius: 8 }} />
            <Bar key="wth-bar" dataKey="mm" fill="#4a9b3a" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function AnalyticsTab() {
  return (
    <div className="p-5 space-y-4">
      <h2 className="font-display font-bold text-xl text-gray-800">Analytics</h2>
      <div className="rounded-2xl p-5" style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
        <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider mb-4">Moisture Trend — Today</p>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={moistureHistory}>
            <defs>
              <linearGradient id="mGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#4a9b3a" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#4a9b3a" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid key="anl-grid" strokeDasharray="3 3" stroke="rgba(26,64,32,0.07)" />
            <XAxis key="anl-x" dataKey="time" tick={{ fontFamily: "JetBrains Mono", fontSize: 10, fill: "#567a52" }} axisLine={false} tickLine={false} />
            <YAxis key="anl-y" tick={{ fontFamily: "JetBrains Mono", fontSize: 10, fill: "#567a52" }} axisLine={false} tickLine={false} width={28} domain={[20, 80]} />
            <Tooltip key="anl-tt" contentStyle={{ fontFamily: "JetBrains Mono", fontSize: 11, borderRadius: 8 }} />
            <Area key="anl-area" type="monotone" dataKey="value" stroke="#4a9b3a" strokeWidth={2} fill="url(#mGrad)" name="Moisture %" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Water Saved", value: "340 L", icon: "💧", delta: "+12% vs last week" },
          { label: "Yield Est.", value: "4.2 t/ha", icon: "🌾", delta: "On track" },
          { label: "Irrigation Runs", value: "14", icon: "🔄", delta: "This month" },
          { label: "Efficiency", value: "87%", icon: "⚡", delta: "+5% improved" },
        ].map(({ label, value, icon, delta }) => (
          <div key={label}
            className="rounded-xl p-4"
            style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}
          >
            <p className="text-xl mb-2">{icon}</p>
            <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider">{label}</p>
            <p className="font-display font-bold text-gray-800 text-xl">{value}</p>
            <p className="text-xs text-[#4a9b3a] mt-0.5">{delta}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsTab({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="p-5 space-y-4">
      <h2 className="font-display font-bold text-xl text-gray-800">Settings</h2>
      {/* Profile */}
      <div className="rounded-2xl p-5 flex items-center gap-4"
        style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
          style={{ background: "#ddebd8" }}>
          👨‍🌾
        </div>
        <div>
          <p className="font-display font-bold text-gray-800">Ramesh Kumar</p>
          <p className="text-xs text-gray-400 font-mono-data">+91 98765 43210</p>
          <p className="text-xs text-[#4a9b3a] mt-0.5">Premium Farmer</p>
        </div>
      </div>
      {/* Settings list */}
      <div className="rounded-2xl overflow-hidden" style={{ border: "1px solid rgba(26,64,32,0.1)" }}>
        {[
          { icon: "🌾", label: "Farm Details", sub: "12 Acres · Wheat · Pune" },
          { icon: "🔔", label: "Notifications", sub: "Push & SMS alerts enabled" },
          { icon: "🌐", label: "Language", sub: "English / हिन्दी" },
          { icon: "📡", label: "Sensor Devices", sub: "3 sensors connected" },
          { icon: "🔒", label: "Security", sub: "Change password / PIN" },
          { icon: "❓", label: "Help & Support", sub: "FAQs, chat support" },
        ].map(({ icon, label, sub }, i, arr) => (
          <button key={label}
            className={`w-full flex items-center gap-4 px-5 py-4 text-left bg-white hover:bg-[#f4f7f2] transition-colors ${i < arr.length - 1 ? "border-b border-gray-100" : ""}`}
          >
            <span className="text-xl">{icon}</span>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-gray-800 text-sm">{label}</p>
              <p className="text-xs text-gray-400 truncate">{sub}</p>
            </div>
            <ChevronRight size={16} className="text-gray-300 shrink-0" />
          </button>
        ))}
      </div>
      <button
        onClick={onLogout}
        className="w-full py-3.5 rounded-xl font-semibold text-sm text-white transition-all hover:opacity-90"
        style={{ background: "#c0392b" }}
      >
        Sign Out
      </button>
    </div>
  );
}

function Dashboard({ onLogout }: { onLogout: () => void }) {
  const [nav, setNav] = useState<NavTab>("dashboard");

  const renderContent = () => {
    if (nav === "map") return <MapTab />;
    if (nav === "ai") return <AITab />;
    if (nav === "irrigation") return <IrrigationTab />;
    if (nav === "weather") return <WeatherTab />;
    if (nav === "analytics") return <AnalyticsTab />;
    if (nav === "settings") return <SettingsTab onLogout={onLogout} />;

    // Main dashboard
    return (
      <div className="p-5 space-y-5 pb-2">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider">Season 2025</p>
            <h1 className="font-display font-extrabold text-2xl text-gray-800 leading-tight">
              🌾 Smart Irrigation
            </h1>
            <div className="flex gap-3 mt-1">
              <span className="text-xs font-mono-data text-[#1a4020] bg-[#ddebd8] px-2 py-0.5 rounded-lg">
                Crop: Wheat
              </span>
              <span className="text-xs font-mono-data text-gray-500 bg-gray-100 px-2 py-0.5 rounded-lg">
                12 Acres
              </span>
            </div>
          </div>
          <button className="w-9 h-9 rounded-xl flex items-center justify-center relative"
            style={{ background: "#ddebd8" }}>
            <Bell size={18} style={{ color: "#1a4020" }} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500" />
          </button>
        </div>

        {/* Status cards */}
        <div className="grid grid-cols-2 gap-3">
          <StatusCard
            icon={<Gauge size={18} />}
            label="Moisture Status"
            value="38"
            unit="%"
            sub="🟢 Needs irrigation"
            accent="#4a9b3a"
          />
          <StatusCard
            icon={<CloudRain size={18} />}
            label="Rainfall"
            value="6.5"
            unit="mm"
            sub="Last: Saturday"
            accent="#3b82f6"
          />
          <StatusCard
            icon={<Thermometer size={18} />}
            label="Temperature"
            value="28"
            unit="°C"
            sub="Feels like 31°C"
            accent="#f97316"
          />
          <StatusCard
            icon={<Droplets size={18} />}
            label="Water Deficit"
            value="18"
            unit="mm"
            sub="⚠️ Moderate stress"
            accent="#c0392b"
          />
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setNav("map")}
            className="flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm border border-[rgba(26,64,32,0.2)] text-[#1a4020] bg-white hover:bg-[#f4f7f2] transition-all"
          >
            <Map size={16} />
            View Map
          </button>
          <button
            onClick={() => setNav("ai")}
            className="flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm text-white transition-all hover:opacity-90"
            style={{ background: "#1a4020" }}
          >
            <Bot size={16} />
            AI Analysis
          </button>
        </div>

        {/* Moisture trend mini chart */}
        <div className="rounded-2xl p-4" style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.1)" }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-mono-data text-gray-400 uppercase tracking-wider">Moisture — Today</p>
            <span className="text-xs font-mono-data text-[#4a9b3a]">38% now</span>
          </div>
          <ResponsiveContainer width="100%" height={100}>
            <AreaChart data={moistureHistory}>
              <defs>
                <linearGradient id="dashMGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4a9b3a" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#4a9b3a" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis key="dash-x" dataKey="time" tick={{ fontFamily: "JetBrains Mono", fontSize: 9, fill: "#a0aec0" }} axisLine={false} tickLine={false} />
              <Tooltip key="dash-tt" contentStyle={{ fontFamily: "JetBrains Mono", fontSize: 10, borderRadius: 8 }} />
              <Area key="dash-area" type="monotone" dataKey="value" stroke="#4a9b3a" strokeWidth={2} fill="url(#dashMGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* AI recommendation strip */}
        <div
          className="rounded-2xl p-4 flex items-center gap-4"
          style={{ background: "linear-gradient(135deg,#1a4020,#2d6b35)" }}
        >
          <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: "rgba(255,255,255,0.15)" }}>
            <Zap size={22} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white/60 text-xs font-mono-data">💧 AI Recommendation</p>
            <p className="text-white font-semibold text-sm">Irrigate within 24 hours</p>
            <p className="text-white/50 text-xs">Required: 20 mm · Priority: High</p>
          </div>
          <button
            onClick={() => setNav("ai")}
            className="shrink-0 w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.15)" }}
          >
            <ChevronRight size={16} className="text-white" />
          </button>
        </div>

        {/* Recent activity */}
        <div>
          <p className="font-semibold text-gray-700 text-sm mb-3">Recent Activity</p>
          <div className="space-y-2">
            {[
              { icon: "💧", text: "Zone A irrigated — 45 min", time: "2h ago", color: "#4a9b3a" },
              { icon: "🌧", text: "Rainfall detected — 6.5 mm", time: "Yesterday", color: "#3b82f6" },
              { icon: "⚠️", text: "Moisture alert — Zone D low", time: "Yesterday", color: "#c0392b" },
              { icon: "🤖", text: "AI analysis complete", time: "2 days ago", color: "#567a52" },
            ].map(({ icon, text, time, color }) => (
              <div key={text}
                className="flex items-center gap-3 rounded-xl px-4 py-3"
                style={{ background: "#fff", border: "1px solid rgba(26,64,32,0.08)" }}
              >
                <span className="text-base">{icon}</span>
                <p className="flex-1 text-sm text-gray-700 min-w-0 truncate">{text}</p>
                <span className="text-xs font-mono-data text-gray-400 shrink-0">{time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: "#f2f6f0", fontFamily: "'DM Sans', sans-serif" }}
    >
      <style>{`
        .font-display { font-family: 'Outfit', sans-serif; }
        .font-mono-data { font-family: 'JetBrains Mono', monospace; }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scrollbar-hide pb-24">
        {renderContent()}
      </div>

      {/* Bottom nav */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 border-t"
        style={{
          background: "rgba(255,255,255,0.95)",
          backdropFilter: "blur(12px)",
          borderColor: "rgba(26,64,32,0.1)",
        }}
      >
        <div className="flex">
          {navItems.map(({ key, icon, label }) => (
            <button
              key={key}
              onClick={() => setNav(key)}
              className="flex-1 flex flex-col items-center gap-0.5 py-2.5 transition-all"
              style={{ color: nav === key ? "#1a4020" : "#a0aec0" }}
            >
              <span className={`transition-transform ${nav === key ? "scale-110" : "scale-100"}`}>
                {icon}
              </span>
              <span
                className="font-mono-data leading-none"
                style={{ fontSize: 9, fontWeight: nav === key ? 700 : 400 }}
              >
                {label}
              </span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  if (!loggedIn) return <LoginPage onLogin={() => setLoggedIn(true)} />;
  return <Dashboard onLogout={() => setLoggedIn(false)} />;
}
