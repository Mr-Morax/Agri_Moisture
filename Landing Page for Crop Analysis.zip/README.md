
  # Landing Page for Crop Analysis

  This is a code bundle for Landing Page for Crop Analysis. The original project is available at https://www.figma.com/design/I9QyUwH5WBlHftiQQyBhcG/Landing-Page-for-Crop-Analysis.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  